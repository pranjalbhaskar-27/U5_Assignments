import { Offer } from "./offer";
export const Home = () => {
  return (
    <div>
      <Offer />
      
    </div>
  );
};
